# TailorTalk

An AI-powered calendar assistant using FastAPI, Streamlit, and Langchain.