# Google Calendar utility functions
def check_availability(start_time, end_time):
    # Dummy implementation
    return True

def book_event(summary, start_time, end_time):
    # Dummy implementation
    return {"status": "success", "summary": summary}
