from fastapi import FastAPI
from app.calendar_utils import check_availability, book_event
from app.langchain_agent import agent_response

app = FastAPI()

@app.get("/")
def root():
    return {"message": "TailorTalk API is running"}

@app.post("/chat/")
def chat_with_agent(message: str):
    return {"response": agent_response(message)}
