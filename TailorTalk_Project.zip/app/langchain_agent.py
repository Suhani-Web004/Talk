# Langchain agent logic
def agent_response(message):
    # Dummy response
    if "book" in message.lower():
        return "Booking confirmed!"
    return "How can I help you?"
