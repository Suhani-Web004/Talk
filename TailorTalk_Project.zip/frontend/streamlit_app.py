import streamlit as st
import requests

st.title("TailorTalk - AI Calendar Assistant")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

if user_input := st.chat_input("Ask something..."):
    st.session_state.messages.append({"role": "user", "content": user_input})
    res = requests.post("http://localhost:8000/chat/", params={"message": user_input})
    response = res.json()["response"]
    st.session_state.messages.append({"role": "assistant", "content": response})
    st.chat_message("assistant").write(response)
